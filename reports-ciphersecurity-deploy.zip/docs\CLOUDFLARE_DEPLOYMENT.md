# Cloudflare Pages Deployment

This section explains how to deploy your Discord Reporting Website to Cloudflare Pages.

## Prerequisites

1. A Cloudflare account
2. Your Discord application set up with OAuth credentials
3. A Discord webhook URL for notifications

## Step 1: Prepare for Production

### Database Setup

For production, you'll want to use a proper database instead of SQLite. Update your Prisma schema:

1. Change the database provider in `prisma/schema.prisma`:
```prisma
datasource db {
  provider = "postgresql" // or "mysql"
  url      = env("DATABASE_URL")
}
```

2. Update your environment variables to use a production database URL.

### Environment Variables

Set these environment variables in the Cloudflare Pages dashboard:

- `DISCORD_CLIENT_ID`: Your Discord application client ID
- `DISCORD_CLIENT_SECRET`: Your Discord application client secret
- `NEXTAUTH_URL`: Your production domain (e.g., `https://your-site.pages.dev`)
- `NEXTAUTH_SECRET`: A random secret string (generate with `openssl rand -base64 32`)
- `DISCORD_WEBHOOK_URL`: Your Discord webhook URL for notifications
- `DATABASE_URL`: Your production database connection string
- `STAFF_USER_IDS`: Comma-separated Discord user IDs for staff access
- `APP_NAME`: "Discord Reporting System"
- `ADMIN_EMAIL`: Your admin email address

## Step 2: Deploy to Cloudflare Pages

### Option 1: GitHub Integration (Recommended)

1. Push your code to a GitHub repository
2. Go to Cloudflare Pages dashboard
3. Click "Create a project"
4. Connect to GitHub and select your repository
5. Configure build settings:
   - Framework preset: `Next.js`
   - Build command: `npm run build`
   - Build output directory: `.next`
6. Add environment variables in the Pages settings
7. Deploy!

### Option 2: Direct Upload

1. Build the project locally:
   ```bash
   npm run build
   ```

2. Use Wrangler CLI:
   ```bash
   npx wrangler pages deploy .next
   ```

## Step 3: Configure Discord OAuth

Update your Discord application settings:

1. Go to Discord Developer Portal
2. Select your application
3. In OAuth2 settings, add your production URL as a redirect URI:
   - `https://your-domain.pages.dev/api/auth/callback/discord`

## Step 4: Set up Database

If using an external database service (recommended):

1. Create a PostgreSQL database on a service like:
   - Neon
   - PlanetScale
   - Supabase
   - Railway

2. Run migrations:
   ```bash
   npx prisma db push
   ```

## Step 5: Test Deployment

1. Visit your deployed site
2. Test the reporting form
3. Test Discord OAuth login
4. Test staff area access
5. Verify Discord webhook notifications

## Monitoring and Maintenance

### Logs

Check Cloudflare Pages logs for any deployment or runtime issues.

### Database Monitoring

Monitor your database performance and storage usage.

### Security

- Regularly rotate your `NEXTAUTH_SECRET`
- Monitor staff user access
- Review Discord webhook logs

## Troubleshooting

### Common Issues

1. **OAuth redirect errors**: Ensure your redirect URI is correctly configured in Discord
2. **Database connection errors**: Verify your `DATABASE_URL` is correct
3. **Environment variables**: Double-check all required environment variables are set
4. **Build failures**: Check that all dependencies are properly installed

### Getting Help

If you encounter issues:

1. Check Cloudflare Pages logs
2. Verify all environment variables
3. Test locally with production environment variables
4. Check Discord Developer Portal settings